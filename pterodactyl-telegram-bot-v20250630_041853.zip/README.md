# Pterodactyl Telegram Control Bot

Bot Telegram untuk kontrol massal Pterodactyl Panel yang memungkinkan restart, reinstall, dan optimasi semua server sekaligus dengan UI/UX yang elegan.

## 🚀 Fitur Utama

- **🔄 Restart All Servers** - Restart semua server secara paralel
- **🔧 Reinstall All Servers** - Reinstall tanpa menghapus konfigurasi
- **⚡ Panel Optimization** - Optimasi database, cache, dan logs
- **🛠️ Server Management** - Kelola server individual atau massal
- **📊 Monitoring & Stats** - Monitor status dan statistik server
- **🔒 Security & Validation** - Rate limiting, access control, logging
- **📱 Elegant UI/UX** - Inline keyboard dengan konfirmasi dialog

## 📋 Persyaratan

- PHP 8.0 atau lebih tinggi
- Composer
- SQLite (untuk logging)
- Pterodactyl Panel dengan API access
- Telegram Bot Token

## 🛠️ Instalasi

### Quick Install (Linux)

```bash
git clone <repository-url>
cd pterodactyl-telegram-bot
chmod +x install.sh
./install.sh
```

### Manual Installation

#### 1. Clone Repository

```bash
git clone <repository-url>
cd pterodactyl-telegram-bot
```

#### 2. Install Dependencies

```bash
composer install --no-dev --optimize-autoloader
```

#### 3. Konfigurasi Environment

```bash
cp .env.example .env
```

Edit file `.env` dengan konfigurasi Anda:

```env
# Telegram Bot Configuration
BOT_TOKEN=your_bot_token_here
BOT_USERNAME=your_bot_username
OWNER_TELEGRAM_ID=your_telegram_id

# Pterodactyl Panel Configuration
PTERODACTYL_PANEL_URL=https://your-panel-domain.com
PTERODACTYL_APPLICATION_API_KEY=ptla_your_application_api_key
PTERODACTYL_CLIENT_API_KEY=ptlc_your_client_api_key

# Security Configuration
ALLOWED_USERS=your_telegram_id
MAX_CONCURRENT_OPERATIONS=10
OPERATION_TIMEOUT=300

# Logging Configuration
LOG_LEVEL=INFO
LOG_FILE=logs/bot.log
LOG_MAX_FILES=7

# Bot Configuration
WEBHOOK_URL=https://your-domain.com/webhook
WEBHOOK_SECRET_TOKEN=your_secret_token
DEBUG_MODE=false
```

### 4. Setup Permissions

```bash
chmod 755 index.php
chmod -R 777 logs/
```

## 🚀 Deployment

### Webhook Mode (Production)

1. **Setup Web Server (Nginx)**

```nginx
server {
    listen 80;
    server_name your-domain.com;
    root /path/to/bot;
    index index.php;

    location / {
        try_files $uri $uri/ /index.php?$query_string;
    }

    location ~ \.php$ {
        fastcgi_pass unix:/var/run/php/php8.1-fpm.sock;
        fastcgi_index index.php;
        fastcgi_param SCRIPT_FILENAME $realpath_root$fastcgi_script_name;
        include fastcgi_params;
    }
}
```

2. **Set Webhook**

```bash
curl "https://your-domain.com/?mode=set_webhook&url=https://your-domain.com/"
```

### Long Polling Mode (Development)

```bash
php index.php?mode=polling
```

### Supervisor (Background Process)

```ini
[program:pterodactyl-bot]
command=php /path/to/bot/index.php?mode=polling
directory=/path/to/bot
autostart=true
autorestart=true
user=www-data
redirect_stderr=true
stdout_logfile=/var/log/pterodactyl-bot.log
```

## 📱 Penggunaan

### Commands Utama

- `/start` - Menu utama bot
- `/restartall` - Restart semua server
- `/reinstallall` - Reinstall semua server
- `/optimize` - Optimasi panel
- `/manage` - Kelola server individual

### Inline Keyboard Navigation

Bot menggunakan inline keyboard untuk navigasi yang mudah:

1. **Main Menu** - Pilih operasi utama
2. **Confirmation Dialog** - Konfirmasi sebelum operasi berbahaya
3. **Server Management** - Kelola server individual
4. **Status & Monitoring** - Lihat statistik dan logs

### Security Features

- **Access Control** - Hanya user yang diizinkan dapat menggunakan bot
- **Rate Limiting** - Mencegah spam dan abuse
- **Operation Tracking** - Monitor operasi yang sedang berjalan
- **Audit Logging** - Log semua aktivitas user

## 🔧 API Endpoints

- `/?mode=webhook` - Webhook endpoint (default)
- `/?mode=polling` - Long polling mode
- `/?mode=set_webhook&url=URL` - Set webhook URL
- `/?mode=delete_webhook` - Delete webhook
- `/?mode=webhook_info` - Get webhook info
- `/?mode=health` - Health check
- `/?mode=stats` - Bot statistics
- `/?mode=cleanup` - Cleanup old data

## 📊 Monitoring

### Health Check

```bash
curl "https://your-domain.com/?mode=health"
```

### Statistics

```bash
curl "https://your-domain.com/?mode=stats&user_id=YOUR_TELEGRAM_ID"
```

### Logs

Logs disimpan di:
- `logs/bot.log` - Application logs
- `logs/bot.db` - SQLite database untuk tracking

## 🛡️ Security

### Best Practices

1. **Environment Variables** - Jangan commit file `.env`
2. **HTTPS Only** - Gunakan HTTPS untuk webhook
3. **Secret Token** - Set webhook secret token
4. **Access Control** - Batasi user yang dapat menggunakan bot
5. **Rate Limiting** - Aktifkan rate limiting
6. **Regular Cleanup** - Jalankan cleanup secara berkala

### Firewall Rules

```bash
# Allow only necessary ports
ufw allow 22/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw enable
```

## 🐛 Troubleshooting

### Common Issues

1. **Bot tidak merespon**
   - Cek webhook status: `/?mode=webhook_info`
   - Cek logs: `tail -f logs/bot.log`
   - Verify bot token dan permissions

2. **API Error**
   - Cek Pterodactyl API keys
   - Verify panel URL dan network connectivity
   - Cek rate limits di panel

3. **Database Error**
   - Cek permissions folder `logs/`
   - Verify SQLite extension installed
   - Cek disk space

### Debug Mode

Enable debug mode di `.env`:

```env
DEBUG_MODE=true
LOG_LEVEL=DEBUG
```

## 📝 Development

### Project Structure

```
/
├── src/
│   ├── Commands/          # Telegram bot commands
│   ├── Services/          # Business logic services
│   └── Bot.php           # Main bot controller
├── logs/                 # Logs dan database
├── .env                  # Environment configuration
├── composer.json         # Dependencies
└── index.php            # Entry point
```

### Adding New Commands

1. Buat class di `src/Commands/`
2. Extend `BaseCommand`
3. Implement required methods
4. Add to bot commands list

### Testing

```bash
# Unit tests
composer test

# Manual testing dengan polling
php index.php?mode=polling
```

## 👨‍💻 Author

**Pablos** ([@ImTamaa](https://t.me/ImTamaa))

## 📄 License

MIT License - see LICENSE file for details.

## 🤝 Contributing

1. Fork repository
2. Create feature branch
3. Commit changes
4. Push to branch
5. Create Pull Request

## 📞 Support

Untuk support dan pertanyaan:
- Telegram: [@ImTamaa](https://t.me/ImTamaa)
- Issues: GitHub Issues

---

**⚠️ Disclaimer**: Bot ini dapat menyebabkan downtime pada server. Gunakan dengan hati-hati dan selalu backup data penting sebelum operasi massal.
